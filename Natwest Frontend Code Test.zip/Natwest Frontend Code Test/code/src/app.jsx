import React, { useEffect } from "react";

import "bootstrap/dist/css/bootstrap.min.css";
import "./app.scss";

const App = () => {
  return <h1>Hello world</h1>;
};

export default App;
